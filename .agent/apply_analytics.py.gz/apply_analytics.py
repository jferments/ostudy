from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text()


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)


def replace_once(path: str, old: str, new: str) -> None:
    content = read(path)
    count = content.count(old)
    if count != 1:
        raise RuntimeError(f"{path}: expected exactly one match, found {count}: {old[:120]!r}")
    write(path, content.replace(old, new, 1))


def replace_all(path: str, old: str, new: str, expected: int) -> None:
    content = read(path)
    count = content.count(old)
    if count != expected:
        raise RuntimeError(f"{path}: expected {expected} matches, found {count}: {old[:120]!r}")
    write(path, content.replace(old, new))


def append_once(path: str, marker: str, content: str) -> None:
    current = read(path)
    if marker in current:
        raise RuntimeError(f"{path}: marker already present: {marker}")
    write(path, current.rstrip() + "\n\n" + content.strip() + "\n")


def main() -> None:
    # Align tests and controller contracts with the new deck-detail sort vocabulary.
    replace_all(
        "src/controllers/domainControllers.test.ts",
        'sort: "updated_desc"',
        'sort: "created_desc"',
        2,
    )
    replace_once(
        "src/ipc/domain-contracts.test.ts",
        'sort: "updated_desc"',
        'sort: "created_desc"',
    )

    replace_once(
        "src/ipc/analytics.ts",
        'export type AnalyticsRange = "7d" | "30d" | "90d" | "1y" | "all";',
        'export type AnalyticsRange = "7d" | "30d" | "90d" | "1y" | "all" | "custom";',
    )
    replace_once(
        "src/ipc/analytics.ts",
        '''  highlightedSessionId?: string;
}''',
        '''  highlightedSessionId?: string;
  customStartLocalDate?: string;
  customEndLocalDate?: string;
}''',
    )

    write(
        "src/screens/analytics/ProgressChart.tsx",
        r'''import { useMemo } from "react";
import {
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Tooltip,
  type ChartData,
  type ChartOptions,
} from "chart.js";
import { Line } from "react-chartjs-2";

import type { AnalyticsRange, TimelineBucket } from "../../ipc/analytics";

ChartJS.register(
  CategoryScale,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
);

interface ProgressChartProps {
  buckets: TimelineBucket[];
  range: AnalyticsRange;
  reduceMotion: boolean;
}

const compactDateFormatter = new Intl.DateTimeFormat(undefined, {
  month: "short",
  day: "numeric",
});
const monthFormatter = new Intl.DateTimeFormat(undefined, {
  month: "short",
  year: "2-digit",
});

type LineChartData = ChartData<"line", number[], string>;

export function ProgressChart({
  buckets,
  range,
  reduceMotion,
}: ProgressChartProps) {
  const colors = readChartColors();
  const labels = useMemo(
    () => buckets.map((bucket) => formatBucketLabel(bucket.startAt, range)),
    [buckets, range],
  );
  const data = useMemo<LineChartData>(
    () => ({
      labels,
      datasets: [
        {
          label: "Cards practiced",
          data: buckets.map((bucket) => bucket.cardsPracticed),
          borderColor: colors.accent,
          backgroundColor: colors.accent,
          pointBackgroundColor: buckets.map((bucket) =>
            bucket.containsHighlightedSession ? colors.warning : colors.accent,
          ),
          pointBorderColor: colors.surface,
          pointBorderWidth: 2,
          pointRadius: buckets.map((bucket) =>
            bucket.containsHighlightedSession ? 5 : bucket.reviewCount > 0 ? 3 : 1,
          ),
          tension: 0.24,
        },
        {
          label: "Cards remembered",
          data: buckets.map((bucket) => bucket.rememberedCount),
          borderColor: colors.success,
          backgroundColor: colors.success,
          pointBackgroundColor: buckets.map((bucket) =>
            bucket.containsHighlightedSession ? colors.warning : colors.success,
          ),
          pointBorderColor: colors.surface,
          pointBorderWidth: 2,
          pointRadius: buckets.map((bucket) =>
            bucket.containsHighlightedSession ? 5 : bucket.reviewCount > 0 ? 3 : 1,
          ),
          tension: 0.24,
        },
      ],
    }),
    [buckets, colors, labels],
  );
  const options = useMemo<ChartOptions<"line">>(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      animation: reduceMotion ? false : { duration: 260 },
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: {
          position: "top",
          align: "start",
          labels: {
            color: colors.textSoft,
            usePointStyle: true,
            boxWidth: 9,
          },
        },
        tooltip: {
          backgroundColor: colors.surfaceRaised,
          titleColor: colors.text,
          bodyColor: colors.textSoft,
          borderColor: colors.border,
          borderWidth: 1,
          callbacks: {
            afterBody(items) {
              const bucket = buckets[items[0]?.dataIndex ?? 0];
              if (!bucket) return [];
              return [
                `${bucket.reviewCount} review${bucket.reviewCount === 1 ? "" : "s"}`,
                `${bucket.newCards} new card${bucket.newCards === 1 ? "" : "s"}`,
                `Remembered rate: ${formatPercent(bucket.correctRate)}`,
                `Confidence: ${formatConfidence(bucket.averageConfidence)}`,
                `Focused time: ${formatDuration(bucket.studyTimeMs)}`,
              ];
            },
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: colors.muted, maxRotation: 0, autoSkip: true },
          border: { color: colors.border },
        },
        y: {
          beginAtZero: true,
          grid: { color: colors.grid },
          ticks: { color: colors.muted, precision: 0 },
          border: { color: colors.border },
          title: {
            display: true,
            text: "Cards",
            color: colors.muted,
          },
        },
      },
    }),
    [buckets, colors, reduceMotion],
  );

  return (
    <div className="progress-chart-canvas">
      <Line
        data={data}
        options={options}
        role="img"
        aria-label={buildAriaLabel(buckets)}
      />
    </div>
  );
}

interface ChartColors {
  accent: string;
  success: string;
  warning: string;
  surface: string;
  surfaceRaised: string;
  text: string;
  textSoft: string;
  muted: string;
  border: string;
  grid: string;
}

function readChartColors(): ChartColors {
  const style = getComputedStyle(document.documentElement);
  const value = (name: string, fallback: string) =>
    style.getPropertyValue(name).trim() || fallback;
  return {
    accent: value("--accent", "#78a9ff"),
    success: value("--success", "#55d79a"),
    warning: value("--warning", "#f5c56b"),
    surface: value("--surface", "#121a28"),
    surfaceRaised: value("--surface-raised", "#182235"),
    text: value("--text", "#edf3fb"),
    textSoft: value("--text-soft", "#b6c1d2"),
    muted: value("--muted", "#7f8da4"),
    border: value("--border", "#2b3950"),
    grid: value("--border", "#2b3950"),
  };
}

function formatBucketLabel(value: number, range: AnalyticsRange): string {
  const date = new Date(value);
  return range === "all" ? monthFormatter.format(date) : compactDateFormatter.format(date);
}

function buildAriaLabel(buckets: TimelineBucket[]): string {
  const active = buckets.filter((bucket) => bucket.reviewCount > 0);
  if (active.length === 0) {
    return "Learning progress chart. No reviews occurred in the selected range.";
  }
  const practiced = active.reduce((total, bucket) => total + bucket.cardsPracticed, 0);
  const remembered = active.reduce((total, bucket) => total + bucket.rememberedCount, 0);
  return `Learning progress chart. One line shows ${practiced} bucket-level cards practiced and the other shows ${remembered} remembered answers.`;
}

function formatPercent(value: number | null): string {
  return value === null ? "no data" : `${Math.round(value * 100)}%`;
}

function formatConfidence(value: number | null): string {
  return value === null ? "no data" : `${value.toFixed(1)} / 3`;
}

function formatDuration(value: number): string {
  if (value < 60_000) return `${Math.round(value / 1_000)} sec`;
  if (value < 3_600_000) return `${Math.round(value / 60_000)} min`;
  const hours = value / 3_600_000;
  return `${hours.toFixed(hours < 10 ? 1 : 0)} hr`;
}
''',
    )

    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''  range: AnalyticsRange;
  selectedDeckIds: Set<string>;''',
        '''  range: AnalyticsRange;
  customStartLocalDate: string;
  customEndLocalDate: string;
  maxLocalDate: string;
  selectedDeckIds: Set<string>;''',
    )
    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''  onRangeChange: (range: AnalyticsRange) => void;
  onDeckIdsChange: (next: Set<string>) => void;''',
        '''  onRangeChange: (range: AnalyticsRange) => void;
  onCustomStartLocalDateChange: (value: string) => void;
  onCustomEndLocalDateChange: (value: string) => void;
  onDeckIdsChange: (next: Set<string>) => void;''',
    )
    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''  { value: "all", label: "All time" },
];''',
        '''  { value: "all", label: "All time" },
  { value: "custom", label: "Custom" },
];''',
    )
    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''  range,
  selectedDeckIds,''',
        '''  range,
  customStartLocalDate,
  customEndLocalDate,
  maxLocalDate,
  selectedDeckIds,''',
    )
    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''  onRangeChange,
  onDeckIdsChange,''',
        '''  onRangeChange,
  onCustomStartLocalDateChange,
  onCustomEndLocalDateChange,
  onDeckIdsChange,''',
    )
    replace_once(
        "src/screens/analytics/AnalyticsFilters.tsx",
        '''      />

      <details className="analytics-scope-details">''',
        '''      />

      {range === "custom" ? (
        <div className="analytics-custom-range" role="group" aria-label="Custom date range">
          <label>
            <span>From</span>
            <input
              type="date"
              value={customStartLocalDate}
              max={customEndLocalDate}
              onChange={(event) => {
                const next = event.currentTarget.value;
                if (next === "") return;
                onCustomStartLocalDateChange(next);
                if (next > customEndLocalDate) onCustomEndLocalDateChange(next);
                onClearHighlightedSession();
              }}
            />
          </label>
          <label>
            <span>Through</span>
            <input
              type="date"
              value={customEndLocalDate}
              min={customStartLocalDate}
              max={maxLocalDate}
              onChange={(event) => {
                const next = event.currentTarget.value;
                if (next === "") return;
                onCustomEndLocalDateChange(next);
                if (next < customStartLocalDate) onCustomStartLocalDateChange(next);
                onClearHighlightedSession();
              }}
            />
          </label>
        </div>
      ) : null}

      <details className="analytics-scope-details">''',
    )

    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''  const [selectedDeckIds, setSelectedDeckIds] = useState<Set<string>>(new Set());''',
        '''  const [customEndLocalDate, setCustomEndLocalDate] = useState(() =>
    formatLocalDateInput(new Date()),
  );
  const [customStartLocalDate, setCustomStartLocalDate] = useState(() =>
    shiftLocalDate(formatLocalDateInput(new Date()), -6),
  );
  const [selectedDeckIds, setSelectedDeckIds] = useState<Set<string>>(new Set());''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [chartMetric, setChartMetric] = useState<"cards" | "time">("cards");
  const [showChartData, setShowChartData] = useState(false);''',
        '''  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [showChartData, setShowChartData] = useState(false);''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''      const result = await controller.load({
        range,
        deckIds,
        tagIds,
        highlightedSessionId,
      });''',
        '''      const result = await controller.load({
        range,
        deckIds,
        tagIds,
        highlightedSessionId,
        ...(range === "custom"
          ? {
              customStartLocalDate,
              customEndLocalDate,
            }
          : {}),
      });''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''  }, [controller, deckIds, highlightedSessionId, range, showToast, tagIds]);''',
        '''  }, [
    controller,
    customEndLocalDate,
    customStartLocalDate,
    deckIds,
    highlightedSessionId,
    range,
    showToast,
    tagIds,
  ]);''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''        range={range}
        selectedDeckIds={selectedDeckIds}''',
        '''        range={range}
        customStartLocalDate={customStartLocalDate}
        customEndLocalDate={customEndLocalDate}
        maxLocalDate={formatLocalDateInput(new Date())}
        selectedDeckIds={selectedDeckIds}''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''        onRangeChange={setRange}
        onDeckIdsChange={setSelectedDeckIds}''',
        '''        onRangeChange={setRange}
        onCustomStartLocalDateChange={setCustomStartLocalDate}
        onCustomEndLocalDateChange={setCustomEndLocalDate}
        onDeckIdsChange={setSelectedDeckIds}''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''              <div className="analytics-chart-actions">
                <div className="segmented-control" role="group" aria-label="Chart volume metric">
                  <button
                    type="button"
                    aria-pressed={chartMetric === "cards"}
                    className={chartMetric === "cards" ? "active" : ""}
                    onClick={() => setChartMetric("cards")}
                  >
                    Cards
                  </button>
                  <button
                    type="button"
                    aria-pressed={chartMetric === "time"}
                    className={chartMetric === "time" ? "active" : ""}
                    onClick={() => setChartMetric("time")}
                  >
                    Study time
                  </button>
                </div>
                <button''',
        '''              <div className="analytics-chart-actions">
                <button''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''              range={analytics.scope.range}
              metric={chartMetric}
              reduceMotion={settings.reduceMotion}''',
        '''              range={analytics.scope.range}
              reduceMotion={settings.reduceMotion}''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''              <td>{formatPercent(bucket.correctRate)}</td>''',
        '''              <td>
                {bucket.rememberedCount}
                <small>{formatPercent(bucket.correctRate)} of reviews</small>
              </td>''',
    )
    replace_once(
        "src/screens/AnalyticsScreen.tsx",
        '''function sameSet(left: Set<string>, right: Set<string>): boolean {
  return left.size === right.size && [...left].every((value) => right.has(value));
}''',
        '''function sameSet(left: Set<string>, right: Set<string>): boolean {
  return left.size === right.size && [...left].every((value) => right.has(value));
}

function formatLocalDateInput(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function shiftLocalDate(value: string, days: number): string {
  const date = new Date(`${value}T12:00:00`);
  date.setDate(date.getDate() + days);
  return formatLocalDateInput(date);
}''',
    )

    append_once(
        "src/styles/features/analytics.css",
        ".analytics-custom-range",
        r'''.analytics-custom-range {
  display: flex;
  align-items: end;
  flex-wrap: wrap;
  gap: 12px;
  border-top: 1px solid var(--border);
  padding-top: 14px;
}

.analytics-custom-range label {
  display: grid;
  min-width: min(100%, 190px);
  gap: 6px;
  color: var(--text-soft);
  font-size: 0.76rem;
  font-weight: 760;
}

.analytics-custom-range input {
  width: 100%;
}

@media (max-width: 620px) {
  .analytics-custom-range {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
  }

  .analytics-custom-range label {
    min-width: 0;
  }
}''',
    )

    replace_once(
        "src-tauri/src/analytics/mod.rs",
        '''    #[serde(default)]
    pub highlighted_session_id: Option<String>,
}''',
        '''    #[serde(default)]
    pub highlighted_session_id: Option<String>,
    #[serde(default)]
    pub custom_start_local_date: Option<String>,
    #[serde(default)]
    pub custom_end_local_date: Option<String>,
}''',
    )
    replace_all(
        "src-tauri/src/analytics/mod.rs",
        '''            highlighted_session_id: None,
''',
        '''            highlighted_session_id: None,
            custom_start_local_date: None,
            custom_end_local_date: None,
''',
        2,
    )
    replace_once(
        "src-tauri/src/stage36_38_regression_tests.rs",
        '''        highlighted_session_id: None,
    }
}''',
        '''        highlighted_session_id: None,
        custom_start_local_date: None,
        custom_end_local_date: None,
    }
}''',
    )

    write(
        "src-tauri/src/analytics/scope.rs",
        r'''use std::collections::BTreeSet;

use chrono::{Duration, NaiveDate};
use rusqlite::types::Value as SqlValue;

use crate::{
    error::CommandError,
    projections::scope::{append_in_filter, push_value},
    study_calendar::{CalendarWindow, StudyTimeContext},
    studyability,
    util::validate_entity_id,
};

use super::{AnalyticsQueryDto, AnalyticsScopeDto};

const MAX_ANALYTICS_DECKS: usize = 256;
const MAX_ANALYTICS_TAGS: usize = 64;
const MAX_CUSTOM_ANALYTICS_DAYS: i64 = 3_660;
const CUSTOM_DAILY_BUCKET_LIMIT: i64 = 62;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AnalyticsRange {
    Days7,
    Days30,
    Days90,
    Year1,
    All,
    Custom,
}

impl AnalyticsRange {
    pub fn parse(value: &str) -> Result<Self, CommandError> {
        match value {
            "7d" => Ok(Self::Days7),
            "30d" => Ok(Self::Days30),
            "90d" => Ok(Self::Days90),
            "1y" => Ok(Self::Year1),
            "all" => Ok(Self::All),
            "custom" => Ok(Self::Custom),
            _ => Err(CommandError::new(
                "invalid_analytics_range",
                "Choose 7 days, 30 days, 90 days, one year, all time, or a custom range.",
            )),
        }
    }

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Days7 => "7d",
            Self::Days30 => "30d",
            Self::Days90 => "90d",
            Self::Year1 => "1y",
            Self::All => "all",
            Self::Custom => "custom",
        }
    }
}

#[derive(Clone, Debug)]
pub struct AnalyticsWindow {
    pub current: Option<CalendarWindow>,
    pub previous: Option<CalendarWindow>,
    pub end_local_date: NaiveDate,
}

#[derive(Clone, Debug)]
pub struct AnalyticsContext {
    pub range: AnalyticsRange,
    pub deck_ids: Vec<String>,
    pub tag_ids: Vec<String>,
    pub highlighted_session_id: Option<String>,
    pub time: StudyTimeContext,
    pub window: AnalyticsWindow,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HistoryPeriod {
    Current,
    CurrentAndPrevious,
}

impl AnalyticsContext {
    pub fn from_query(mut input: AnalyticsQueryDto) -> Result<Self, CommandError> {
        let range = AnalyticsRange::parse(&input.range)?;
        input.deck_ids = normalize_ids(input.deck_ids, "deck", MAX_ANALYTICS_DECKS)?;
        input.tag_ids = normalize_ids(input.tag_ids, "tag", MAX_ANALYTICS_TAGS)?;
        if let Some(session_id) = input.highlighted_session_id.as_deref() {
            validate_entity_id(session_id, "practice session")?;
        }
        let time = StudyTimeContext::capture()?;
        let current = match range {
            AnalyticsRange::Days7 => Some(time.trailing_local_dates(7)?),
            AnalyticsRange::Days30 => Some(time.trailing_local_dates(30)?),
            AnalyticsRange::Days90 => Some(time.trailing_local_dates(90)?),
            AnalyticsRange::Year1 => Some(time.one_year_window()?),
            AnalyticsRange::All => None,
            AnalyticsRange::Custom => Some(custom_window(
                &time,
                input.custom_start_local_date.as_deref(),
                input.custom_end_local_date.as_deref(),
            )?),
        };
        let previous = current
            .as_ref()
            .map(|window| time.adjacent_previous_window(window))
            .transpose()?;
        let end_local_date = current
            .as_ref()
            .map_or(time.local_date, |window| window.end_local_date);
        Ok(Self {
            range,
            deck_ids: input.deck_ids,
            tag_ids: input.tag_ids,
            highlighted_session_id: input.highlighted_session_id,
            time,
            window: AnalyticsWindow {
                current,
                previous,
                end_local_date,
            },
        })
    }

    pub fn dto(&self, earliest_local_date: Option<&str>) -> AnalyticsScopeDto {
        let start_local_date = self
            .window
            .current
            .as_ref()
            .map(|window| window.start_local_date.to_string())
            .or_else(|| earliest_local_date.map(str::to_string));
        let end_at = self
            .window
            .current
            .as_ref()
            .map_or(self.time.now_utc_millis, |window| {
                window.end_utc_millis.saturating_sub(1)
            });
        AnalyticsScopeDto {
            range: self.range.as_str().to_string(),
            start_local_date,
            end_local_date: self.window.end_local_date.to_string(),
            start_at: self
                .window
                .current
                .as_ref()
                .map(|window| window.start_utc_millis),
            end_at,
            bucket_granularity: self.bucket_granularity().to_string(),
            deck_ids: self.deck_ids.clone(),
            tag_ids: self.tag_ids.clone(),
            highlighted_session_id: self.highlighted_session_id.clone(),
        }
    }

    pub fn bucket_step_days(&self) -> Option<i64> {
        match self.range {
            AnalyticsRange::Days7 | AnalyticsRange::Days30 => Some(1),
            AnalyticsRange::Days90 | AnalyticsRange::Year1 => Some(7),
            AnalyticsRange::All => None,
            AnalyticsRange::Custom => self.window.current.as_ref().map(|window| {
                if local_date_count(window) <= CUSTOM_DAILY_BUCKET_LIMIT {
                    1
                } else {
                    7
                }
            }),
        }
    }

    fn bucket_granularity(&self) -> &'static str {
        match self.bucket_step_days() {
            Some(1) => "day",
            Some(_) => "week",
            None => "month",
        }
    }

    pub fn current_card_conditions(&self, values: &mut Vec<SqlValue>) -> Vec<String> {
        let mut conditions = vec![studyability::current_card_sql("c", "n", "d").to_string()];
        append_in_filter(&mut conditions, values, "c.deck_id", &self.deck_ids);
        for tag_id in &self.tag_ids {
            let index = push_value(values, tag_id.clone());
            conditions.push(format!(
                "EXISTS (
                     SELECT 1 FROM note_tags filter_nt
                     WHERE filter_nt.note_id = n.id AND filter_nt.tag_id = ?{index}
                 )"
            ));
        }
        conditions
    }

    pub fn historical_conditions(
        &self,
        values: &mut Vec<SqlValue>,
        period: HistoryPeriod,
    ) -> Vec<String> {
        let mut conditions = vec![
            "c.deleted_at IS NULL".to_string(),
            "n.deleted_at IS NULL".to_string(),
            "d.deleted_at IS NULL".to_string(),
        ];
        append_in_filter(&mut conditions, values, "c.deck_id", &self.deck_ids);
        for tag_id in &self.tag_ids {
            let index = push_value(values, tag_id.clone());
            conditions.push(format!(
                "EXISTS (
                     SELECT 1 FROM review_event_tag_attributions filter_rta
                     WHERE filter_rta.review_event_id = r.id
                       AND filter_rta.tag_id = ?{index}
                 )"
            ));
        }
        match period {
            HistoryPeriod::Current => {
                if let Some(window) = &self.window.current {
                    let start = push_value(values, window.start_local_date.to_string());
                    conditions.push(format!("a.review_local_date >= ?{start}"));
                }
                let end = push_value(values, self.window.end_local_date.to_string());
                conditions.push(format!("a.review_local_date <= ?{end}"));
            }
            HistoryPeriod::CurrentAndPrevious => {
                if let Some(window) = self
                    .window
                    .previous
                    .as_ref()
                    .or(self.window.current.as_ref())
                {
                    let start = push_value(values, window.start_local_date.to_string());
                    conditions.push(format!("a.review_local_date >= ?{start}"));
                }
                let end = push_value(values, self.window.end_local_date.to_string());
                conditions.push(format!("a.review_local_date <= ?{end}"));
            }
        }
        conditions
    }

    pub fn previous_window(&self) -> Option<&CalendarWindow> {
        self.window.previous.as_ref()
    }
}

fn custom_window(
    time: &StudyTimeContext,
    start_value: Option<&str>,
    end_value: Option<&str>,
) -> Result<CalendarWindow, CommandError> {
    let start_local_date = parse_custom_date(start_value, "start")?;
    let end_local_date = parse_custom_date(end_value, "end")?;
    if start_local_date > end_local_date {
        return Err(CommandError::new(
            "invalid_custom_analytics_range",
            "The custom analytics start date must be on or before the end date.",
        ));
    }
    if end_local_date > time.local_date {
        return Err(CommandError::new(
            "future_custom_analytics_range",
            "The custom analytics range cannot end in the future.",
        ));
    }
    let date_count = end_local_date
        .signed_duration_since(start_local_date)
        .num_days()
        .saturating_add(1);
    if !(1..=MAX_CUSTOM_ANALYTICS_DAYS).contains(&date_count) {
        return Err(CommandError::new(
            "custom_analytics_range_too_large",
            "Choose a custom analytics range of ten years or less.",
        ));
    }
    let next_local_date = checked_add_days(end_local_date, 1)?;
    let end_utc_millis = if end_local_date == time.local_date {
        time.now_utc_millis.saturating_add(1)
    } else {
        time.first_valid_instant(next_local_date)?
    };
    Ok(CalendarWindow {
        start_local_date,
        end_local_date,
        start_utc_millis: time.first_valid_instant(start_local_date)?,
        end_utc_millis,
    })
}

fn parse_custom_date(value: Option<&str>, label: &str) -> Result<NaiveDate, CommandError> {
    let value = value.ok_or_else(|| {
        CommandError::new(
            "missing_custom_analytics_range",
            format!("Choose a custom analytics {label} date."),
        )
    })?;
    NaiveDate::parse_from_str(value, "%Y-%m-%d").map_err(|_| {
        CommandError::new(
            "invalid_custom_analytics_date",
            format!("Choose a valid custom analytics {label} date."),
        )
    })
}

fn local_date_count(window: &CalendarWindow) -> i64 {
    window
        .end_local_date
        .signed_duration_since(window.start_local_date)
        .num_days()
        .saturating_add(1)
}

fn checked_add_days(date: NaiveDate, days: i64) -> Result<NaiveDate, CommandError> {
    date.checked_add_signed(Duration::days(days)).ok_or_else(|| {
        CommandError::new(
            "invalid_analytics_date",
            "The analytics date range is outside the supported calendar.",
        )
    })
}

fn normalize_ids(
    values: Vec<String>,
    label: &str,
    maximum: usize,
) -> Result<Vec<String>, CommandError> {
    if values.len() > maximum {
        return Err(CommandError::new(
            "too_many_analytics_filters",
            format!("Filter analytics by at most {maximum} {label}s."),
        ));
    }
    let mut unique = BTreeSet::new();
    for value in values {
        validate_entity_id(&value, label)?;
        unique.insert(value);
    }
    Ok(unique.into_iter().collect())
}
''',
    )

    replace_once(
        "src-tauri/src/analytics/timeline.rs",
        '''    match context.range {
        AnalyticsRange::All => load_months(connection, context, earliest_local_date),
        _ => load_local_date_buckets(connection, context),
    }''',
        '''    match context.range {
        AnalyticsRange::All => load_months(connection, context, earliest_local_date),
        _ => load_local_date_buckets(connection, context),
    }''',
    )
    # The match remains explicit for all-time; custom ranges use bounded local-date buckets.
    replace_once(
        "src-tauri/src/analytics/timeline.rs",
        '''    let step_days = context.range.step_days().unwrap_or(1);''',
        '''    let step_days = context.bucket_step_days().unwrap_or(1);''',
    )

    replace_once(
        "src/screens/AnalyticsScreen.test.tsx",
        '''  it("changes the range and starts a scoped ready session for a weak tag", async () => {''',
        '''  it("loads an explicit custom calendar range", async () => {
    renderAnalytics();

    await screen.findByText("Cards practiced");
    fireEvent.click(screen.getByRole("radio", { name: "Custom" }));
    fireEvent.change(screen.getByLabelText("From"), {
      target: { value: "2026-01-01" },
    });
    fireEvent.change(screen.getByLabelText("Through"), {
      target: { value: "2026-01-31" },
    });

    await waitFor(() => {
      expect(analyticsIpc.getAnalytics).toHaveBeenLastCalledWith(
        expect.objectContaining({
          range: "custom",
          customStartLocalDate: "2026-01-01",
          customEndLocalDate: "2026-01-31",
        }),
      );
    });
  });

  it("changes the range and starts a scoped ready session for a weak tag", async () => {''',
    )


if __name__ == "__main__":
    main()

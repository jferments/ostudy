#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    content = read(path)
    count = content.count(old)
    if count != 1:
        raise RuntimeError(f"{path}: expected one match, found {count}: {old[:120]!r}")
    write(path, content.replace(old, new, 1))


def replace_all(path: str, old: str, new: str, expected: int) -> None:
    content = read(path)
    count = content.count(old)
    if count != expected:
        raise RuntimeError(f"{path}: expected {expected} matches, found {count}: {old[:120]!r}")
    write(path, content.replace(old, new))


def main() -> None:
    replace_once(
        "src/App.tsx",
        '''const DecksScreen = lazy(() =>
  import("./screens/DecksScreen").then((module) => ({ default: module.DecksScreen })),
);''',
        '''const DecksWorkspace = lazy(() =>
  import("./screens/DecksWorkspace").then((module) => ({ default: module.DecksWorkspace })),
);''',
    )
    replace_once(
        "src/App.tsx",
        '''            {controller.section === "decks" ? (
              <DecksScreen
                decks={controller.decks}
                settings={controller.activeSettings}
                refreshDecks={controller.refreshDecks}
                onPracticeDeck={controller.practiceDeck}
                onDirtyChange={controller.setHasUnsavedCard}
                showToast={controller.showToast}
              />
            ) : null}''',
        '''            {controller.section === "decks" ? (
              <DecksWorkspace
                decks={controller.decks}
                settings={controller.activeSettings}
                refreshDecks={controller.refreshDecks}
                onPracticeDeck={controller.practiceDeck}
                onPracticeCards={controller.practiceCards}
                onManageTemplates={() => controller.navigate("templates")}
                onDirtyChange={controller.setHasUnsavedCard}
                showToast={controller.showToast}
              />
            ) : null}''',
    )
    replace_once(
        "src/App.tsx",
        '''              <TemplatesScreen
                onDirtyChange={controller.setHasUnsavedTemplate}
                showToast={controller.showToast}
              />''',
        '''              <TemplatesScreen
                onBack={() => controller.navigate("decks")}
                onDirtyChange={controller.setHasUnsavedTemplate}
                showToast={controller.showToast}
              />''',
    )

    replace_once(
        "src/components/NavigationSidebar.tsx",
        '''const ITEMS: ReadonlyArray<{ section: AppSection; icon: string; label: string }> = [
  { section: "decks", icon: "▤", label: "Decks" },
  { section: "documents", icon: "▣", label: "Documents" },
  { section: "cards", icon: "⌕", label: "Search/Filter" },
  { section: "templates", icon: "▧", label: "Templates" },
  { section: "practice", icon: "▶", label: "Practice" },
  { section: "analytics", icon: "▥", label: "Analytics" },
  { section: "settings", icon: "⚙", label: "Settings" },
];

const COMPACT_SECTIONS = new Set<AppSection>(["decks", "cards", "practice", "analytics"]);''',
        '''const ITEMS: ReadonlyArray<{ section: AppSection; icon: string; label: string }> = [
  { section: "decks", icon: "▤", label: "Decks" },
  { section: "documents", icon: "▣", label: "Documents" },
  { section: "practice", icon: "▶", label: "Practice" },
  { section: "analytics", icon: "▥", label: "Analytics" },
  { section: "settings", icon: "⚙", label: "Settings" },
];

const COMPACT_SECTIONS = new Set<AppSection>(["decks", "practice", "analytics"]);

function isActive(item: AppSection, current: AppSection): boolean {
  if (item === "decks") {
    return current === "decks" || current === "cards" || current === "templates";
  }
  return item === current;
}''',
    )
    replace_all(
        "src/components/NavigationSidebar.tsx",
        'section === item.section',
        'isActive(item.section, section)',
        4,
    )
    replace_once(
        "src/components/NavigationSidebar.tsx",
        '<span>{item.label === "Search/Filter" ? "Search" : item.label}</span>',
        '<span>{item.label}</span>',
    )
    replace_once(
        "src/components/NavigationSidebar.tsx",
        'data-active={!COMPACT_SECTIONS.has(section)}',
        'data-active={!COMPACT_SECTIONS.has(section) && !isActive("decks", section)}',
    )

    write(
        "src/screens/DecksWorkspace.tsx",
        '''import { useState } from "react";

import type { ShowToast } from "../components/Toast";
import type { DeckSummary } from "../ipc/decks";
import type { AppSettings } from "../ipc/settings";
import { CardsScreen } from "./CardsScreen";
import { DecksScreen } from "./DecksScreen";
import { BulkEntryModal } from "./cards/BulkEntryModal";

interface DecksWorkspaceProps {
  decks: DeckSummary[];
  settings: AppSettings;
  refreshDecks: () => Promise<DeckSummary[]>;
  onPracticeDeck: (deckId: string) => void | Promise<void>;
  onPracticeCards: (cardIds: string[]) => void | Promise<void>;
  onManageTemplates: () => void | Promise<void>;
  onDirtyChange: (dirty: boolean) => void;
  showToast: ShowToast;
}

type DeckWorkspaceView = "library" | "detail" | "editor";

export function DecksWorkspace({
  decks,
  settings,
  refreshDecks,
  onPracticeDeck,
  onPracticeCards,
  onManageTemplates,
  onDirtyChange,
  showToast,
}: DecksWorkspaceProps) {
  const [bulkOpen, setBulkOpen] = useState(false);
  const [deckView, setDeckView] = useState<DeckWorkspaceView>("library");

  return (
    <div className="decks-workspace">
      <DecksScreen
        decks={decks}
        settings={settings}
        refreshDecks={refreshDecks}
        onPracticeDeck={onPracticeDeck}
        onManageTemplates={onManageTemplates}
        onBulkAdd={() => setBulkOpen(true)}
        onViewChange={setDeckView}
        onDirtyChange={onDirtyChange}
        showToast={showToast}
      />

      {deckView === "library" ? (
        <section className="decks-global-search" aria-labelledby="all-cards-search-heading">
          <div className="decks-global-search-heading">
            <div>
              <span className="eyebrow">CARD LIBRARY</span>
              <h2 id="all-cards-search-heading">Search and filter cards</h2>
              <p>Search every active deck or narrow the results to selected decks.</p>
            </div>
          </div>
          <CardsScreen
            embedded
            decks={decks}
            refreshDecks={refreshDecks}
            onPracticeCards={onPracticeCards}
            onDirtyChange={onDirtyChange}
            showToast={showToast}
          />
        </section>
      ) : null}

      {bulkOpen ? (
        <BulkEntryModal
          decks={decks}
          onClose={() => setBulkOpen(false)}
          onSaved={async () => {
            setBulkOpen(false);
            await refreshDecks();
          }}
          showToast={showToast}
        />
      ) : null}
    </div>
  );
}
''',
    )

    replace_once(
        "src/screens/CardsScreen.tsx",
        '''interface CardsScreenProps {
  decks: DeckSummary[];
  refreshDecks: () => Promise<DeckSummary[]>;
  onPracticeCards: (cardIds: string[]) => void;
  onDirtyChange: (dirty: boolean) => void;
  showToast: (kind: "success" | "error" | "info", text: string) => void;
}''',
        '''interface CardsScreenProps {
  decks: DeckSummary[];
  refreshDecks: () => Promise<DeckSummary[]>;
  onPracticeCards: (cardIds: string[]) => void;
  onDirtyChange: (dirty: boolean) => void;
  showToast: (kind: "success" | "error" | "info", text: string) => void;
  embedded?: boolean;
}''',
    )
    replace_once(
        "src/screens/CardsScreen.tsx",
        '''export function CardsScreen({
  decks,
  refreshDecks,
  onPracticeCards,
  onDirtyChange,
  showToast,
}: CardsScreenProps) {''',
        '''export function CardsScreen({
  decks,
  refreshDecks,
  onPracticeCards,
  onDirtyChange,
  showToast,
  embedded = false,
}: CardsScreenProps) {''',
    )
    replace_once(
        "src/screens/CardsScreen.tsx",
        '''      <header className="screen-header compact-screen-header">
        <div>
          <h1>Search/Filter</h1>
          <p>
            Find independently scheduled generated cards and manage exact card schedules without
            changing sibling presentations.
          </p>
        </div>
        <div className="header-actions wrap-actions">
          <button
            type="button"
            className="secondary-button"
            disabled={activeDecks.length === 0}
            onClick={() => setBulkOpen(true)}
          >
            Bulk add
          </button>
          <button
            type="button"
            className="primary-button"
            disabled={!selectedDeck}
            title={
              selectedDeck ? undefined : "Select exactly one active deck before adding a card"
            }
            onClick={() => {
              if (!selectedDeck) return;
              setEditingCard(null);
              setCreatingDeckId(selectedDeck.id);
            }}
          >
            Add card
          </button>
        </div>
      </header>''',
        '''      {!embedded ? (
        <header className="screen-header compact-screen-header">
          <div>
            <h1>Search/Filter</h1>
            <p>
              Find independently scheduled cards and manage exact schedules without changing
              sibling presentations.
            </p>
          </div>
          <div className="header-actions wrap-actions">
            <button
              type="button"
              className="secondary-button"
              disabled={activeDecks.length === 0}
              onClick={() => setBulkOpen(true)}
            >
              Bulk add
            </button>
            <button
              type="button"
              className="primary-button"
              disabled={!selectedDeck}
              title={
                selectedDeck ? undefined : "Select exactly one active deck before adding a card"
              }
              onClick={() => {
                if (!selectedDeck) return;
                setEditingCard(null);
                setCreatingDeckId(selectedDeck.id);
              }}
            >
              Add card
            </button>
          </div>
        </header>
      ) : null}''',
    )

    replace_once(
        "src/screens/DecksScreen.tsx",
        '''import { openFile, saveFile } from "../platform/files";
import { useConfirm } from "../ui/overlays/overlayContext";''',
        '''import { openFile, saveFile } from "../platform/files";
import { useMediaQuery } from "../ui/hooks/useMediaQuery";
import { useConfirm } from "../ui/overlays/overlayContext";''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''  refreshDecks: () => Promise<DeckSummary[]>;
  onPracticeDeck: (deckId: string) => void | Promise<void>;
  onDirtyChange: (dirty: boolean) => void;
  showToast: ShowToast;''',
        '''  refreshDecks: () => Promise<DeckSummary[]>;
  onPracticeDeck: (deckId: string) => void | Promise<void>;
  onManageTemplates?: () => void | Promise<void>;
  onBulkAdd?: () => void;
  onViewChange?: (view: DeckView) => void;
  onDirtyChange: (dirty: boolean) => void;
  showToast: ShowToast;''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''  refreshDecks,
  onPracticeDeck,
  onDirtyChange,
  showToast,
}: DecksScreenProps) {''',
        '''  refreshDecks,
  onPracticeDeck,
  onManageTemplates,
  onBulkAdd,
  onViewChange,
  onDirtyChange,
  showToast,
}: DecksScreenProps) {''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [cardSort, setCardSort] = useState<"updated_desc" | "question_asc">("updated_desc");
  const controllerRef = useRef<DecksController | null>(null);''',
        '''  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const [cardSort, setCardSort] = useState<
    "created_desc" | "practiced_desc" | "practiced_asc"
  >("created_desc");
  const controllerRef = useRef<DecksController | null>(null);''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''  const controller = controllerRef.current;
  const confirm = useConfirm();

  const selectedDeckId = selectedDeck?.id ?? null;

  useEffect(() => () => controller.invalidate(), [controller]);''',
        '''  const controller = controllerRef.current;
  const confirm = useConfirm();
  const compact = useMediaQuery("(max-width: 760px)");

  const selectedDeckId = selectedDeck?.id ?? null;
  const activeDecks = decks.filter((deck) => deck.archivedAt === null);
  const archivedDecks = decks.filter((deck) => deck.archivedAt !== null);

  useEffect(() => () => controller.invalidate(), [controller]);
  useEffect(() => onViewChange?.(view), [onViewChange, view]);
  useEffect(() => {
    if (!compact) setSearchDialogOpen(false);
  }, [compact]);''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '      setCardSort("updated_desc");',
        '      setCardSort("created_desc");',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''        description: `This will delete ${deck.sourceNoteCount} ${
          deck.sourceNoteCount === 1 ? "source note" : "source notes"
        } and every generated card. Review history will also be permanently removed after the Undo period.`,''',
        '''        description: `This will delete ${deck.generatedCardCount} ${
          deck.generatedCardCount === 1 ? "card" : "cards"
        } and their review history after the Undo period.`,''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''        description: `The source note and its ${card.generatedCardCount} generated ${
          card.generatedCardCount === 1 ? "card" : "cards"
        } will be deleted. Review history will also be removed after the Undo period. ${
          card.questionExcerpt || "Image card"
        }`,''',
        '''        description: `This card entry and its ${card.generatedCardCount} scheduled ${
          card.generatedCardCount === 1 ? "card" : "card variants"
        } will be deleted. Review history will also be removed after the Undo period. ${
          card.questionExcerpt || "Image card"
        }`,''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''          `Imported ${result.createdNoteCount} source ${
            result.createdNoteCount === 1 ? "note" : "notes"
          } as ${result.createdCardCount} scheduled ${
            result.createdCardCount === 1 ? "card" : "cards"
          }.${duplicateMessage}`,''',
        '''          `Imported ${result.createdNoteCount} ${
            result.createdNoteCount === 1 ? "card entry" : "card entries"
          } as ${result.createdCardCount} ${
            result.createdCardCount === 1 ? "scheduled card" : "scheduled cards"
          }.${duplicateMessage}`,''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''            <div className="header-actions">
              <button
                type="button"
                className="secondary-button"
                disabled={isTransferring}
                onClick={() => void handleImport()}
              >''',
        '''            <div className="header-actions">
              {onManageTemplates ? (
                <button
                  type="button"
                  className="secondary-button"
                  onClick={() => void onManageTemplates()}
                >
                  Manage templates
                </button>
              ) : null}
              {onBulkAdd ? (
                <button
                  type="button"
                  className="secondary-button"
                  disabled={activeDecks.length === 0}
                  onClick={onBulkAdd}
                >
                  Bulk add
                </button>
              ) : null}
              <button
                type="button"
                className="secondary-button"
                disabled={isTransferring}
                onClick={() => void handleImport()}
              >''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '{decks.length === 0 ? (',
        '{activeDecks.length === 0 ? (',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '{decks.map((deck) => {',
        '{activeDecks.map((deck) => {',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''            </section>
          )}
        </>
      ) : null}

      {view === "detail" && selectedDeck ? (''',
        '''            </section>
          )}

          {archivedDecks.length > 0 ? (
            <section className="archived-decks-section" aria-labelledby="archived-decks-heading">
              <button
                type="button"
                className="archived-decks-toggle"
                aria-expanded={showArchived}
                onClick={() => setShowArchived((current) => !current)}
              >
                <span>
                  <strong id="archived-decks-heading">Archived decks</strong>
                  <small>{archivedDecks.length} stored with cards suspended</small>
                </span>
                <span aria-hidden="true">{showArchived ? "▴" : "▾"}</span>
              </button>
              {showArchived ? (
                <div className="deck-grid archived-deck-grid">
                  {archivedDecks.map((deck) => (
                    <article key={deck.id} className="deck-card archived">
                      <div className="deck-card-main">
                        <span className="deck-card-mark" aria-hidden="true">
                          ▤
                        </span>
                        <span className="deck-card-copy">
                          <strong>{deck.name}</strong>
                          <span>Archived · cards suspended</span>
                        </span>
                        <span className="deck-card-count">
                          <strong>{deck.generatedCardCount}</strong>
                          <small>{deck.generatedCardCount === 1 ? "card" : "cards"}</small>
                        </span>
                      </div>
                      <div className="deck-card-actions">
                        <button type="button" onClick={() => void handleArchiveDeck(deck, false)}>
                          Unarchive
                        </button>
                        <button
                          type="button"
                          disabled={isTransferring}
                          onClick={() => void handleExport(deck)}
                        >
                          Export
                        </button>
                        <button
                          type="button"
                          className="danger-text"
                          onClick={() => void handleDeleteDeck(deck)}
                        >
                          Delete
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              ) : null}
            </section>
          ) : null}
        </>
      ) : null}

      {view === "detail" && selectedDeck ? (''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''            <div className="card-browser-toolbar">
              <label className="search-field">
                <span>Search this deck</span>
                <input
                  type="search"
                  value={search}
                  onChange={(event) => setSearch(event.currentTarget.value)}
                  placeholder="Search questions and answers"
                />
              </label>
              <label>
                <span>Sort</span>
                <select
                  value={cardSort}
                  onChange={(event) =>
                    setCardSort(event.currentTarget.value as "updated_desc" | "question_asc")
                  }
                >
                  <option value="updated_desc">Recently updated</option>
                  <option value="question_asc">Question A–Z</option>
                </select>
              </label>
              <span className="card-count-summary">
                {cardTotalCount} {cardTotalCount === 1 ? "source note" : "source notes"}
                {` · ${selectedDeck.generatedCardCount} generated ${
                  selectedDeck.generatedCardCount === 1 ? "card" : "cards"
                }`}
                {selectedDeck.studyableDueCount > 0
                  ? ` · ${selectedDeck.studyableDueCount} ready now`
                  : ""}
              </span>
            </div>''',
        '''            <div className="card-browser-toolbar">
              {compact ? (
                <button
                  type="button"
                  className="deck-search-trigger"
                  aria-label="Search this deck"
                  title={search ? `Search: ${search}` : "Search this deck"}
                  onClick={() => setSearchDialogOpen(true)}
                >
                  <span aria-hidden="true">⌕</span>
                  <span className="sr-only">Search this deck</span>
                </button>
              ) : (
                <label className="search-field">
                  <span>Search this deck</span>
                  <input
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.currentTarget.value)}
                    placeholder="Search questions and answers"
                  />
                </label>
              )}
              <label>
                <span>Sort</span>
                <select
                  value={cardSort}
                  onChange={(event) =>
                    setCardSort(
                      event.currentTarget.value as
                        | "created_desc"
                        | "practiced_desc"
                        | "practiced_asc",
                    )
                  }
                >
                  <option value="created_desc">Time created</option>
                  <option value="practiced_desc">Most recently practiced</option>
                  <option value="practiced_asc">Least recently practiced</option>
                </select>
              </label>
              <span className="card-count-summary">
                {cardTotalCount} {cardTotalCount === 1 ? "Card" : "Cards"}
                {selectedDeck.studyableDueCount > 0
                  ? ` · ${selectedDeck.studyableDueCount} ready now`
                  : ""}
              </span>
            </div>''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        "<small>Question / source</small>",
        "<small>Question</small>",
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''                        {card.generatedCardCount} generated · {card.imageCount > 0
                          ? `${card.imageCount} image${card.imageCount === 1 ? "" : "s"}`
                          : "Text"}''',
        '''                        {card.generatedCardCount}{" "}
                        {card.generatedCardCount === 1 ? "card" : "card variants"} ·{" "}
                        {card.imageCount > 0
                          ? `${card.imageCount} image${card.imageCount === 1 ? "" : "s"}`
                          : "Text"}''',
    )
    replace_once(
        "src/screens/DecksScreen.tsx",
        '''      {deckDialog ? (
        <DeckFormModal
          mode={deckDialog}
          deck={deckDialog === "edit" ? selectedDeck : null}
          onClose={() => setDeckDialog(null)}
          onSave={handleDeckSaved}
        />
      ) : null}
    </div>''',
        '''      {deckDialog ? (
        <DeckFormModal
          mode={deckDialog}
          deck={deckDialog === "edit" ? selectedDeck : null}
          onClose={() => setDeckDialog(null)}
          onSave={handleDeckSaved}
        />
      ) : null}

      {searchDialogOpen ? (
        <Modal
          title="Search this deck"
          description={`Find cards in ${selectedDeck?.name ?? "this deck"}.`}
          onClose={() => setSearchDialogOpen(false)}
          width="small"
        >
          <div className="form-stack">
            <label>
              <span>Search questions and answers</span>
              <input
                data-autofocus="true"
                type="search"
                value={search}
                onChange={(event) => setSearch(event.currentTarget.value)}
                placeholder="Enter a word or phrase"
              />
            </label>
            <div className="modal-actions">
              {search ? (
                <button type="button" className="secondary-button" onClick={() => setSearch("")}>
                  Clear
                </button>
              ) : null}
              <button
                type="button"
                className="primary-button"
                onClick={() => setSearchDialogOpen(false)}
              >
                Done
              </button>
            </div>
          </div>
        </Modal>
      ) : null}
    </div>''',
    )

    replace_once(
        "src/ipc/decks.ts",
        '  sort: "updated_desc" | "question_asc";',
        '  sort: "created_desc" | "practiced_desc" | "practiced_asc";',
    )
    replace_once(
        "src-tauri/src/deck_cards.rs",
        '''    let order_sql = match input.sort.as_str() {
        "question_asc" => "n.front_text COLLATE NOCASE ASC, n.updated_at DESC, n.id ASC",
        _ => "n.updated_at DESC, n.created_at DESC, n.id ASC",
    };''',
        '''    let order_sql = match input.sort.as_str() {
        "practiced_desc" => {
            "MAX(r.reviewed_at) IS NULL ASC, MAX(r.reviewed_at) DESC, n.created_at DESC, n.id ASC"
        }
        "practiced_asc" => {
            "MAX(r.reviewed_at) IS NULL DESC, MAX(r.reviewed_at) ASC, n.created_at DESC, n.id ASC"
        }
        _ => "n.created_at DESC, n.id ASC",
    };''',
    )
    replace_once(
        "src-tauri/src/deck_cards.rs",
        '''         JOIN decks d ON d.id = n.deck_id
         LEFT JOIN cards c ON c.note_id = n.id
         LEFT JOIN note_assets na ON na.note_id = n.id''',
        '''         JOIN decks d ON d.id = n.deck_id
         LEFT JOIN cards c ON c.note_id = n.id
         LEFT JOIN review_events r ON r.card_id = c.id
         LEFT JOIN note_assets na ON na.note_id = n.id''',
    )
    replace_once(
        "src-tauri/src/deck_cards.rs",
        '''    if !matches!(input.sort.as_str(), "updated_desc" | "question_asc") {
        return Err(CommandError::new(
            "invalid_deck_card_sort",
            "Sort deck cards by recent update or question.",
        ));
    }''',
        '''    if !matches!(
        input.sort.as_str(),
        "created_desc" | "practiced_desc" | "practiced_asc"
    ) {
        return Err(CommandError::new(
            "invalid_deck_card_sort",
            "Sort deck cards by creation time or practice history.",
        ));
    }''',
    )
    replace_once(
        "src-tauri/src/deck_cards.rs",
        '''fn default_sort() -> String {
    "updated_desc".to_string()
}''',
        '''fn default_sort() -> String {
    "created_desc".to_string()
}''',
    )

    write(
        "src/screens/practice/ActivePractice.tsx",
        '''import { useEffect, useRef } from "react";

import { RichTextView } from "../../editor/RichTextView";
import {
  type PracticeCard,
  type PracticeSession,
  type ReviewPreviewSet,
} from "../../ipc/practice";
import {
  type RescheduleIntent,
  type ScheduleAction,
} from "../../ipc/scheduling";
import { useExperience } from "../../ui/feedback/ExperienceProvider";
import { Menu } from "../../ui/overlays/Menu";
import { useOverlayContext } from "../../ui/overlays/overlayContext";
import { Progress } from "../../ui/primitives/Progress";
import type { ConfidenceScore } from "./confidence";

interface ActivePracticeProps {
  session: PracticeSession;
  current: PracticeCard;
  position: number;
  revealed: boolean;
  ratedCount: number;
  previewSet: ReviewPreviewSet | null;
  isRevealing: boolean;
  isRating: boolean;
  isEnding: boolean;
  isManaging: boolean;
  flipAnimationEnabled?: boolean;
  errorMessage: string | null;
  onReveal: () => void;
  onScore: (score: ConfidenceScore) => void;
  onScheduleAction: (action: ScheduleAction, intent?: RescheduleIntent) => void;
  onEnd: () => void;
  onLinkError: (message: string) => void;
}

export function ActivePractice({
  session,
  current,
  position,
  revealed,
  ratedCount,
  previewSet,
  isRevealing,
  isRating,
  isEnding,
  isManaging,
  flipAnimationEnabled = false,
  errorMessage,
  onReveal,
  onScore,
  onScheduleAction,
  onEnd,
  onLinkError,
}: ActivePracticeProps) {
  const ratingPanelRef = useRef<HTMLElement | null>(null);
  const wasRevealed = useRef(revealed);
  const busy = isRevealing || isRating || isEnding || isManaging;
  const { topId } = useOverlayContext();
  const experience = useExperience();

  useEffect(() => {
    if (revealed) ratingPanelRef.current?.focus();
    if (revealed && !wasRevealed.current) experience.emit({ type: "answer_revealed" });
    wasRevealed.current = revealed;
  }, [experience, revealed]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent): void {
      if (busy || event.repeat || topId !== null) return;
      const target = event.target;
      if (
        target instanceof HTMLElement &&
        (target.isContentEditable ||
          ["INPUT", "TEXTAREA", "SELECT", "BUTTON", "A", "SUMMARY"].includes(target.tagName))
      ) {
        return;
      }
      if (!revealed && (event.key === " " || event.key === "Enter")) {
        event.preventDefault();
        onReveal();
        return;
      }
      if (revealed && ["0", "1", "2", "3"].includes(event.key)) {
        event.preventDefault();
        onScore(Number(event.key) as ConfidenceScore);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [busy, onReveal, onScore, revealed, topId]);

  return (
    <div className="screen practice-screen active-practice-screen">
      <header className="practice-session-header">
        <div>
          <span className="eyebrow">
            {session.mode === "extra"
              ? "EXTRA PRACTICE"
              : session.mode === "custom"
                ? "CUSTOM PRACTICE"
                : "PRACTICE"}
          </span>
          <h1>{current.deckName}</h1>
          {current.needsMorePractice ? (
            <span className="schedule-status-badge needs-practice">Needs more practice</span>
          ) : null}
        </div>
        <div className="practice-progress-copy">
          <strong>
            {position + 1} / {session.cardCount}
          </strong>
          <span>{ratedCount} reviewed</span>
        </div>
        <div className="practice-header-actions">
          <Menu
            label="More"
            disabled={busy}
            items={[
              {
                label: "Bury until tomorrow",
                onSelect: () => onScheduleAction("bury"),
              },
              {
                label: "Suspend card",
                onSelect: () => onScheduleAction("suspend"),
              },
              {
                label: "Reschedule for tomorrow",
                onSelect: () => onScheduleAction("reschedule", { kind: "tomorrow" }),
              },
              {
                label: "Reset schedule",
                destructive: true,
                onSelect: () => onScheduleAction("reset"),
              },
            ]}
          />
          <button
            type="button"
            className="secondary-button"
            disabled={busy}
            onClick={onEnd}
          >
            {isEnding ? "Ending…" : "End session"}
          </button>
        </div>
      </header>

      <Progress
        className="practice-progress-track"
        label="Practice session progress"
        value={Math.min(position + 1, session.cardCount)}
        max={session.cardCount}
      />

      {errorMessage ? <div className="inline-alert error-alert">{errorMessage}</div> : null}

      {flipAnimationEnabled ? (
        <section
          className="practice-card-surface practice-flip-card"
          data-revealed={revealed}
          role={revealed ? undefined : "button"}
          tabIndex={revealed ? undefined : 0}
          aria-label={revealed ? undefined : "Reveal answer"}
          aria-disabled={!revealed && busy ? "true" : undefined}
          onClick={(event) => {
            const target = event.target;
            if (
              !revealed &&
              !busy &&
              !(
                target instanceof HTMLElement &&
                target.closest("a, button, input, textarea, select")
              )
            ) {
              onReveal();
            }
          }}
        >
          <div className="practice-flip-inner">
            <div className="practice-flip-face practice-flip-front" aria-hidden={revealed}>
              <span className="practice-side-label">Question</span>
              <RichTextView
                document={current.presentation.frontDoc}
                assets={current.presentation.assets}
                onLinkError={onLinkError}
              />
              {!revealed ? (
                <small className="practice-flip-hint">Click the card to flip it</small>
              ) : null}
            </div>
            <div className="practice-flip-face practice-flip-back" aria-hidden={!revealed}>
              <span className="practice-side-label">Answer</span>
              <RichTextView
                document={current.presentation.backDoc}
                assets={current.presentation.assets}
                onLinkError={onLinkError}
              />
            </div>
          </div>
        </section>
      ) : (
        <section className="practice-card-surface">
          <span className="practice-side-label">Question</span>
          <RichTextView
            document={current.presentation.frontDoc}
            assets={current.presentation.assets}
            onLinkError={onLinkError}
          />
          {revealed ? (
            <>
              <div className="practice-answer-divider" />
              <span className="practice-side-label">Answer</span>
              <RichTextView
                document={current.presentation.backDoc}
                assets={current.presentation.assets}
                onLinkError={onLinkError}
              />
            </>
          ) : null}
        </section>
      )}

      {!revealed ? (
        <div className="practice-primary-action">
          <button
            type="button"
            className="primary-button large-action-button"
            disabled={isRevealing}
            onClick={onReveal}
          >
            {isRevealing ? "Calculating intervals…" : "Show answer"}
          </button>
        </div>
      ) : (
        <section
          ref={ratingPanelRef}
          tabIndex={-1}
          className="review-rating-panel confidence-rating-panel"
          aria-labelledby="confidence-rating-heading"
        >
          <div className="confidence-rating-heading">
            <h2 id="confidence-rating-heading">How difficult was that answer?</h2>
            <p>Choose the result that best matches your recall.</p>
          </div>
          <div className="confidence-score-actions">
            <ConfidenceButton
              score={0}
              label="Wrong"
              disabled={isRating || !previewSet}
              onClick={() => onScore(0)}
            />
            <ConfidenceButton
              score={1}
              label="Hard"
              disabled={isRating || !previewSet}
              onClick={() => onScore(1)}
            />
            <ConfidenceButton
              score={2}
              label="Medium"
              disabled={isRating || !previewSet}
              onClick={() => onScore(2)}
            />
            <ConfidenceButton
              score={3}
              label="Easy"
              disabled={isRating || !previewSet}
              onClick={() => onScore(3)}
            />
          </div>
        </section>
      )}
    </div>
  );
}

function ConfidenceButton({
  score,
  label,
  disabled,
  onClick,
}: {
  score: ConfidenceScore;
  label: string;
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`confidence-score-button confidence-score-${score}`}
      disabled={disabled}
      aria-label={`${score} ${label}`}
      aria-keyshortcuts={String(score)}
      onClick={onClick}
    >
      <span className="confidence-score-number" aria-hidden="true">
        {score}
      </span>
      <span className="confidence-score-copy">
        <strong>{label}</strong>
      </span>
    </button>
  );
}
''',
    )
    replace_once(
        "src/screens/PracticeScreen.tsx",
        '''        isManaging={isManaging || isLoadingWindow}
        errorMessage={errorMessage}''',
        '''        isManaging={isManaging || isLoadingWindow}
        flipAnimationEnabled={!settings.reduceMotion}
        errorMessage={errorMessage}''',
    )

    replace_once(
        "src/screens/settings/AppearanceSettings.tsx",
        '''        <label className={styles.switchRow}>
          <span><strong>Reduce motion</strong><small>Minimize nonessential transitions and effects.</small></span>
          <input
            type="checkbox"
            checked={draft.reduceMotion}
            onChange={(event) => update({ reduceMotion: event.currentTarget.checked })}
          />
        </label>''',
        '''        <label className={styles.switchRow}>
          <span>
            <strong>Animations and transitions</strong>
            <small>Enable card flips and other nonessential motion effects.</small>
          </span>
          <input
            type="checkbox"
            checked={!draft.reduceMotion}
            onChange={(event) => update({ reduceMotion: !event.currentTarget.checked })}
          />
        </label>''',
    )

    replace_once(
        "src/screens/settings/AiLlmSettings.tsx",
        'import type { ReactNode } from "react";',
        'import { useState, type ReactNode } from "react";',
    )
    replace_once(
        "src/screens/settings/AiLlmSettings.tsx",
        '''function CredentialPanel({ controller }: { controller: AiProfilesController }) {
  const profile = controller.selectedProfile;''',
        '''function CredentialPanel({ controller }: { controller: AiProfilesController }) {
  const [credentialVisible, setCredentialVisible] = useState(false);
  const profile = controller.selectedProfile;''',
    )
    replace_once(
        "src/screens/settings/AiLlmSettings.tsx",
        '''        <input
          type="password"
          autoComplete="off"
          value={controller.credentialDraft}
          placeholder={hasCredential ? "Enter a replacement" : "Credential is never readable after saving"}
          onChange={(event) => controller.setCredentialDraft(event.currentTarget.value)}
        />''',
        '''        <span className={aiStyles.credentialField}>
          <input
            type={credentialVisible ? "text" : "password"}
            autoComplete="off"
            value={controller.credentialDraft}
            placeholder={
              hasCredential ? "Enter a replacement" : "Credential is never readable after saving"
            }
            onChange={(event) => controller.setCredentialDraft(event.currentTarget.value)}
          />
          <button
            type="button"
            className={aiStyles.credentialVisibility}
            aria-label={credentialVisible ? "Hide API credential" : "Show API credential"}
            aria-pressed={credentialVisible}
            onClick={() => setCredentialVisible((current) => !current)}
          >
            <svg aria-hidden="true" viewBox="0 0 24 24">
              {credentialVisible ? (
                <>
                  <path d="M3 3l18 18" />
                  <path d="M10.6 10.6a2 2 0 002.8 2.8" />
                  <path d="M9.9 4.3A10.7 10.7 0 0112 4c5 0 8.7 4.1 9.7 5.4a1 1 0 010 1.2 17.8 17.8 0 01-3.1 3.3" />
                  <path d="M6.2 6.2A18.4 18.4 0 002.3 9.4a1 1 0 000 1.2C3.3 11.9 7 16 12 16c1 0 2-.2 2.9-.5" />
                </>
              ) : (
                <>
                  <path d="M2.3 9.4C3.3 8.1 7 4 12 4s8.7 4.1 9.7 5.4a1 1 0 010 1.2C20.7 11.9 17 16 12 16s-8.7-4.1-9.7-5.4a1 1 0 010-1.2z" />
                  <path d="M12 13a3 3 0 100-6 3 3 0 000 6z" />
                </>
              )}
            </svg>
          </button>
        </span>''',
    )
    write(
        "src/screens/settings/AiLlmSettings.module.css",
        read("src/screens/settings/AiLlmSettings.module.css")
        + '''

.credentialField {
  position: relative;
  display: block;
}

.credentialField input {
  width: 100%;
  padding-right: 48px;
}

.credentialVisibility {
  position: absolute;
  top: 50%;
  right: 4px;
  display: grid;
  width: 40px;
  height: 40px;
  place-items: center;
  transform: translateY(-50%);
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--muted);
}

.credentialVisibility:hover,
.credentialVisibility:focus-visible {
  background: var(--surface-strong);
  color: var(--text);
}

.credentialVisibility svg {
  width: 20px;
  height: 20px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
''',
    )

    replace_once(
        "src/screens/TemplatesScreen.tsx",
        '''interface TemplatesScreenProps {
  onDirtyChange: (dirty: boolean) => void;
  showToast: ShowToast;
}''',
        '''interface TemplatesScreenProps {
  onBack?: () => void | Promise<void>;
  onDirtyChange: (dirty: boolean) => void;
  showToast: ShowToast;
}''',
    )
    replace_once(
        "src/screens/TemplatesScreen.tsx",
        '''export function TemplatesScreen({ onDirtyChange, showToast }: TemplatesScreenProps) {''',
        '''export function TemplatesScreen({ onBack, onDirtyChange, showToast }: TemplatesScreenProps) {''',
    )
    replace_once(
        "src/screens/TemplatesScreen.tsx",
        '''        <div>
          <h1>Templates</h1>
          <p>Build reusable rich entry forms that generate permanent Basic cards.</p>
        </div>''',
        '''        <div>
          {onBack ? (
            <button type="button" className="back-button" onClick={() => void onBack()}>
              ← Decks
            </button>
          ) : null}
          <h1>Templates</h1>
          <p>Build reusable rich entry forms that generate permanent Basic cards.</p>
        </div>''',
    )

    replace_once(
        "src/ui/foundations/index.css",
        '@import "../../styles/features/assets.css" layer(features);',
        '''@import "../../styles/features/assets.css" layer(features);
@import "../../styles/features/ui-overhaul.css" layer(features);''',
    )
    write(
        "src/styles/features/ui-overhaul.css",
        '''.decks-workspace {
  min-width: 0;
}

.decks-workspace > .decks-screen {
  min-height: auto;
  padding-bottom: var(--space-5);
}

.decks-global-search {
  border-top: 1px solid var(--border);
}

.decks-global-search-heading {
  padding: var(--space-7) clamp(20px, 4vw, 48px) 0;
}

.decks-global-search-heading h2,
.decks-global-search-heading p {
  margin: 0;
}

.decks-global-search-heading p {
  margin-top: var(--space-2);
  color: var(--muted);
}

.decks-global-search > .screen {
  min-height: auto;
  padding-top: var(--space-5);
}

.archived-decks-section {
  display: grid;
  gap: var(--space-4);
  margin-top: var(--space-6);
}

.archived-decks-toggle {
  display: flex;
  width: 100%;
  min-height: var(--touch-target-min);
  align-items: center;
  justify-content: space-between;
  gap: var(--space-4);
  border: 1px solid var(--border);
  border-radius: var(--radius-large);
  padding: var(--space-4) var(--space-5);
  background: var(--surface);
  color: var(--text);
  text-align: left;
}

.archived-decks-toggle > span:first-child {
  display: grid;
  gap: 3px;
}

.archived-decks-toggle small {
  color: var(--muted);
}

.archived-deck-grid {
  margin-top: 0;
}

.deck-search-trigger {
  display: grid;
  width: var(--touch-target-min);
  min-width: var(--touch-target-min);
  min-height: var(--touch-target-min);
  place-items: center;
  border: 1px solid var(--border);
  border-radius: var(--radius-medium);
  padding: 0;
  background: var(--surface);
  color: var(--text);
  font-size: 1.25rem;
}

.card-count-summary {
  min-width: 0;
  overflow-wrap: anywhere;
}

.practice-flip-card {
  min-height: clamp(260px, 42vh, 520px);
  padding: 0;
  cursor: pointer;
  perspective: 1200px;
}

.practice-flip-card[data-revealed="true"] {
  cursor: default;
}

.practice-flip-inner {
  position: relative;
  display: grid;
  min-height: inherit;
  transform-style: preserve-3d;
  transition: transform 560ms var(--ease-standard);
}

.practice-flip-card[data-revealed="true"] .practice-flip-inner {
  transform: rotateY(180deg);
}

.practice-flip-face {
  grid-area: 1 / 1;
  min-width: 0;
  padding: clamp(22px, 5vw, 52px);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
}

.practice-flip-back {
  transform: rotateY(180deg);
}

.practice-flip-hint {
  display: block;
  margin-top: var(--space-6);
  color: var(--muted);
  text-align: center;
}

.confidence-score-button {
  min-height: 88px;
  grid-template-columns: auto 1fr;
}

.confidence-score-copy {
  align-content: center;
}

.confidence-score-copy strong {
  font-size: 1.05rem;
}

@media (max-width: 760px) {
  .practice-screen:not(.active-practice-screen) {
    display: flex;
    flex-direction: column;
  }

  .practice-screen:not(.active-practice-screen) > .practice-setup-panel {
    order: 10;
  }

  .practice-screen:not(.active-practice-screen) > .practice-workload-panel {
    order: 20;
  }

  .practice-screen:not(.active-practice-screen) > .recent-practice-section {
    order: 30;
  }

  .decks-global-search-heading {
    padding-inline: 18px;
  }

  .decks-global-search > .screen {
    padding-inline: 18px;
  }

  .deck-detail-header .header-actions {
    width: 100%;
  }

  .card-browser-toolbar {
    display: grid;
    grid-template-columns: var(--touch-target-min) minmax(150px, 1fr);
    gap: var(--space-3);
  }

  .card-browser-toolbar > label {
    min-width: 0;
  }

  .card-count-summary {
    grid-column: 1 / -1;
    width: 100%;
  }

  .practice-workload-panel {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 0;
    padding: 0;
  }

  .practice-workload-panel > div {
    min-height: 104px;
    border-right: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
    padding: var(--space-4);
  }

  .practice-workload-panel > div:nth-child(2n) {
    border-right: 0;
  }

  .practice-workload-panel > div:nth-last-child(-n + 2) {
    border-bottom: 0;
  }

  .workload-loading {
    grid-column: 1 / -1;
    padding: var(--space-2) var(--space-4);
  }

  .confidence-score-actions {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .confidence-score-button {
    min-height: 76px;
    padding: var(--space-3);
  }

  .practice-flip-card {
    min-height: clamp(240px, 45vh, 420px);
  }

  .practice-flip-face {
    padding: var(--space-5);
  }
}

@media (max-width: 460px) {
  .card-browser-toolbar {
    grid-template-columns: var(--touch-target-min) minmax(0, 1fr);
  }

  .confidence-score-actions {
    grid-template-columns: 1fr 1fr;
  }
}
''',
    )

    replace_once(
        "src/components/NavigationSidebar.test.tsx",
        '''    for (const label of [
      "Decks",
      "Documents",
      "Search/Filter",
      "Templates",
      "Practice",
      "Analytics",
      "Settings",
    ]) {''',
        '''    for (const label of ["Decks", "Documents", "Practice", "Analytics", "Settings"]) {''',
    )
    replace_once(
        "src/components/NavigationSidebar.test.tsx",
        '''    expect(navigation).toBeTruthy();
    expect(screen.queryByRole("button", { name: "More" })).toBeNull();''',
        '''    expect(navigation).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Search/Filter" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Templates" })).toBeNull();
    expect(screen.queryByRole("button", { name: "More" })).toBeNull();''',
    )
    replace_once(
        "src/components/NavigationSidebar.test.tsx",
        '    for (const label of ["Decks", "Search", "Practice", "Analytics", "More"]) {',
        '    for (const label of ["Decks", "Practice", "Analytics", "More"]) {',
    )

    replace_once(
        "src/App.test.tsx",
        'vi.mock("./screens/DecksScreen", () => ({\n  DecksScreen:',
        'vi.mock("./screens/DecksWorkspace", () => ({\n  DecksWorkspace:',
    )

    replace_once(
        "src/screens/practice/ActivePractice.test.tsx",
        '  it("shows all FSRS previews and submits 0-3 keyboard scores after reveal", () => {',
        '  it("shows concise ratings and submits 0-3 keyboard scores after reveal", () => {',
    )
    replace_once(
        "src/screens/practice/ActivePractice.test.tsx",
        '''    expect(screen.getByRole("button", { name: /0 Wrong, About 1 min/u })).toBeTruthy();
    expect(screen.getByRole("button", { name: /1 Hard, About 1 hr/u })).toBeTruthy();
    expect(screen.getByRole("button", { name: /2 Medium, About 1 day/u })).toBeTruthy();
    expect(screen.getByRole("button", { name: /3 Easy, About 1 month/u })).toBeTruthy();''',
        '''    expect(screen.getByRole("button", { name: "0 Wrong" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "1 Hard" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "2 Medium" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "3 Easy" })).toBeTruthy();
    expect(screen.queryByText(/About 1/u)).toBeNull();
    expect(screen.queryByText("I could not recall it.")).toBeNull();''',
    )
    replace_once(
        "src/screens/practice/ActivePractice.test.tsx",
        '''  it("does not steal reveal shortcuts from interactive controls", () => {
    const props = renderActive();
    const input = document.createElement("input");
    document.body.append(input);

    fireEvent.keyDown(input, { key: "Enter" });
    fireEvent.keyDown(screen.getByRole("button", { name: "Show answer" }), {
      key: " ",
    });

    expect(props.onReveal).not.toHaveBeenCalled();
    input.remove();
  });

  it("shows concise ratings''',
        '''  it("does not steal reveal shortcuts from interactive controls", () => {
    const props = renderActive();
    const input = document.createElement("input");
    document.body.append(input);

    fireEvent.keyDown(input, { key: "Enter" });
    fireEvent.keyDown(screen.getByRole("button", { name: "Show answer" }), {
      key: " ",
    });

    expect(props.onReveal).not.toHaveBeenCalled();
    input.remove();
  });

  it("reveals when the animated card surface is clicked", () => {
    const props = renderActive({ flipAnimationEnabled: true });

    fireEvent.click(screen.getByRole("button", { name: "Reveal answer" }));

    expect(props.onReveal).toHaveBeenCalledOnce();
  });

  it("shows concise ratings''',
    )

    replace_once(
        "src/screens/DecksScreen.test.tsx",
        '"Imported 15 source notes as 15 scheduled cards."',
        '"Imported 15 card entries as 15 scheduled cards."',
    )
    replace_once(
        "src/screens/DecksScreen.extended.test.tsx",
        '"Imported 2 source notes as 3 scheduled cards. 4 exact duplicates were skipped."',
        '"Imported 2 card entries as 3 scheduled cards. 4 exact duplicates were skipped."',
    )


if __name__ == "__main__":
    main()
